import React from "react";
import styled from "styled-components";

import { COLORS } from "./constants";

const Button = ({ variant, size, children }) => {
  switch (variant) {
    case "fill":
      return <FillButton size={size}>{children}</FillButton>;
    case "outline":
      return <OutlineButton size={size}>{children}</OutlineButton>;
    case "ghost":
      return <GhostButton size={size}>{children}</GhostButton>;
  }
};

const BaseButton = styled.button`
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen,
    Ubuntu, Cantarell, "Open Sans", "Helvetica Neue", sans-serif;
  font-size: ${(props) => fontSize(props.size)};

  border-radius: ${(props) => borderRadius(props.size)};
  padding: ${(props) => padding(props.size)};
  text-transform: uppercase;
  border: 2px solid transparent;

  &:focus {
    outline: 2px solid currentColor;
    outline-offset: 1px;
  }
`;

const FillButton = styled(BaseButton)`
  background: ${COLORS.primary};
  color: ${COLORS.white};

  &:hover {
    background: ${COLORS.primaryLight};
  }

  &:focus {
    outline: 2px solid ${COLORS.primary};
  }
`;

const OutlineButton = styled(BaseButton)`
  background: ${COLORS.white};
  color: ${COLORS.primary};
  border: 2px solid ${COLORS.primary};

  &:hover {
    background: ${COLORS.offwhite};
  }
`;

const GhostButton = styled(BaseButton)`
  background: none;
  color: ${COLORS.transparentGray75};

  &:hover {
    background: ${COLORS.transparentGray15};
  }
`;

const fontSize = (sizeName) => {
  switch (sizeName) {
    case "small":
      return "16px";

    case "large":
      return "21px";

    default:
      return "18px";
  }
};

const borderRadius = (sizeName) => {
  switch (sizeName) {
    case "small":
      return "1px";

    case "large":
      return "4px";

    default:
      return "2px";
  }
};

const padding = (sizeName) => {
  switch (sizeName) {
    case "small":
      return "8px 16px";

    case "large":
      return "20px 36px";

    default:
      return "16px 24px";
  }
};

export default Button;
