import React from "react";

import ButtonTable from "./ButtonTable";

export default function App() {
  return <ButtonTable />;
}
